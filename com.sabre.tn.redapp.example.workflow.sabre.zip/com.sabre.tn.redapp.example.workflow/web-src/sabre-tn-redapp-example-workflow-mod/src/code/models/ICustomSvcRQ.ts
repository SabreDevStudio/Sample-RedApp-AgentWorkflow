export interface ICustomSvcRQ {
    'workflowdata.CustomSvcRQ': [{'workflowdata.actionCode': string,
        'workflowdata.rqPayload': string}];
}