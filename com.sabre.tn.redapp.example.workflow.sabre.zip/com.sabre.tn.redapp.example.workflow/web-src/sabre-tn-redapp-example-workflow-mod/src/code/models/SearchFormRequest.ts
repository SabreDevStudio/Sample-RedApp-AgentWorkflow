export interface SearchFormRequest {
    'com_sabre_redapp_example3_web_form.SearchFormRqStruct': [{
        'com_sabre_redapp_example3_web_form.tripId': string;
        'com_sabre_redapp_example3_web_form.customerName': string;
    }];
}