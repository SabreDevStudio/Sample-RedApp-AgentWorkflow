export interface State {
    [key: string]: any;
}