/// <ngv scope="public" />

/*************************************/
/* Auto-generated file.              */
/* Do not modify it.                 */
/* You may remove it.                */
/* You may commit it.                */
/* You may push it.                  */
/* Remove it if module name changed. */
/* tslint:disable                    */
/*************************************/

import {IModuleContext} from "sabre-ngv-core/modules/IModuleContext";
import {ModuleContext} from "sabre-ngv-core/modules/ModuleContext";

/** @internal **/
export const context: IModuleContext = new ModuleContext();
/** @internal **/
export const cf = context.cf.bind(context);
/** @internal **/
export const registerService = context.registerService.bind(context);
/** @internal **/
export const getService = context.getService.bind(context);
