export const TRIP_ID = 'tripId';
export const CUSTOMER_NAME = 'customerName';